bananadashdemo
==============

MSX turboR cartridge, built with nes2msxtr.

UxROM, PRG 512K, CHR RAM, mirroring horizontal
mapper segments used: 4..52 (848K RAM needed, more than the turboR's 512K: runs from a RAM expansion (memory mapper))

Needs an MSX turboR (FS-A1ST/FS-A1GT) with a V9990 (GFX9000), or openMSX with the FS-A1GT system ROMs: https://openmsx.org/
If it needs more RAM than the machine has, a memory mapper RAM expansion cartridge, found automatically at boot.

Load bananadashdemo.rom as an ASCII16 cartridge.
